# Init for employees package
