# Init for migrations package
