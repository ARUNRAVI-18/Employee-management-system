# Init for config package
